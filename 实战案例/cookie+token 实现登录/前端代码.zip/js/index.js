var loginAction = (function(){
  var oModal = document.getElementsByClassName('js_modal')[0],
      oUserName = document.getElementById('js_username'),
      oPassword = document.getElementById('js_password'),
      oPersistedLogin = document.getElementById('js_persistedLogin'),
      oErrorTip = document.getElementsByClassName('js_errorTip')[0],
      oLoginStatus = document.getElementsByClassName('js_loginStatus')[0],
      
      loginTpl = document.getElementById('js_loginTpl').innerHTML,
      userTpl = document.getElementById('js_userTpl').innerHTML;

  return {
  	openLoginBoard: function(){
      oModal.style.display = 'block';
  	},

  	closeLoginBoard: function(){
  		oModal.style.display = 'none';
  		oUserName.value = '';
  		oPassword.value = '';
  		oPersistedLogin.checked = false;
  	},

  	login: function(){
      var username = trimSpace(oUserName.value),
          password = trimSpace(oPassword.value);
          

      if(username.length < 6 || username.length > 20){
        oErrorTip.innerHTML = '用户名长度：6-20位';
        return;
      }

      if(password.length < 6 || password.length > 20){
        oErrorTip.innerHTML = '密码长度：6-20位';
        return;
      }

      this.submitForm(username, password);
  	},

  	submitForm: function(username, password){
      var isPersistedLogin = oPersistedLogin.checked;

      xhr.ajax({
        url: 'http://localhost/api_for_study/User/login',
        type: 'POST',
        dataType: 'JSON',
        data: {
          username: username,
          password: password,
          isPersistedLogin: isPersistedLogin
        },
        success: function(data){
          var code = data.error_code;

          switch(code){
            case '1001':
              oErrorTip.innerHTML = '用户名长度不正确';
              break;
            case '1002':
              oErrorTip.innerHTML = '密码长度不正确';
              break;
            case '1003':
              oErrorTip.innerHTML = '此用户名不存在';
              break;
            case '1004':
              oErrorTip.innerHTML = '密码不正确';
              break;
            case '1005':
              oErrorTip.innerHTML = '登录失败，请重新登录';
              break;
            case '200':
              location.reload();
              break;
            default:
              break;
          }
        }
      });
  	},

    checkAuth: function(){
      var _self = this;
      console.log(1);
      manageCookies.get('auth', function(data){
        if(data != undefined){
          xhr.ajax({
            url: 'http://localhost/api_for_study/User/checkAuth',
            type: 'POST',
            dataType: 'JSON',
            data: {
              auth: data
            },
            success: function(data){
              var code = data.error_code;

              switch(code){
                case '1005':
                  oErrorTip.innerHTML = '登录失败，请重新登录',
                  _self.openLoginBoard();
                  _self.render(false);
                  break;
                case '1006':
                  oErrorTip.innerHTML = '登录验证错误，请重新登录',
                  _self.openLoginBoard();
                  _self.render(false);
                  break;
                case '1007':
                  oErrorTip.innerHTML = '登录已过期，请重新登录',
                  _self.openLoginBoard();
                  _self.render(false);
                  break;
                case '200':
                  _self.render(true);
                  break;
                default:
                  break;
              }
            }
          });
        }
      });
    },

    render: function(isLogin){
      if(isLogin){
        manageCookies.get('nickname', function(data){
          oLoginStatus.innerHTML = userTpl.replace(/{{(.*?)}}/g, data);
        });
      }else{
        oLoginStatus.innerHTML = loginTpl;
      }
    }
  }
})();

;(function(){
  var oOpenBtn = document.getElementsByClassName('js_openBtn')[0],
      oCloseBtn = document.getElementsByClassName('js_closeBtn')[0],
      oLoginBtn = document.getElementsByClassName('js_loginBtn')[0];
  
  var init = function(){
  	bindEvent();
    loginAction.checkAuth.call(loginAction);
  }

  function bindEvent(){
  	oOpenBtn.addEventListener('click', loginAction.openLoginBoard, false);
    oCloseBtn.addEventListener('click', loginAction.closeLoginBoard, false);
    oLoginBtn.addEventListener('click', loginAction.login.bind(loginAction), false);
  }

  init();
})();